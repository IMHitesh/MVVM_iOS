//
//  MovieViewModel.swift
//  MVVMBaseCode
//
//  Created by sooryen on 12/06/19.
//  Copyright © 2019 sooryen. All rights reserved.
//

import Foundation


protocol MovieViewModelDelegate: class {
    func APISuccess()
    func APIFailure(message:String)
}

class MovieViewModel:NSObject {
    
    var aryMoviesList  = [MoviesList]()
    weak var delegate: MovieViewModelDelegate?

    init(_ movieDelegate:MovieViewModelDelegate) {
        delegate = movieDelegate
    }
    
    func getMovies(inMainThread:Bool) {
        if inMainThread {showLoader()}
        API.sharedInstance.apiRequestWithModalClass(modelClass: ModeMoviesList.self, apiName: APIName.MoviesList, requestType: .get, paramValues: nil, headersValues: nil, SuccessBlock: { (response) in
            
            if inMainThread {
                self.hideLoader()
                self.aryMoviesList.removeAll()
            }
            
            guard let result = response.results else{
                return
            }
            self.aryMoviesList.append(contentsOf: result)
            self.delegate?.APISuccess()
        }) { (error) in
            self.delegate?.APIFailure(message: error.localizedDescription)
            if inMainThread {self.hideLoader()}
        }
    }
}
