//
//  ParentNavigationController.swift
//  MVVMBaseCode
//
//  Created by sooryen on 13/06/19.
//  Copyright © 2019 sooryen. All rights reserved.
//

import UIKit

class ParentNavigationController: UINavigationController {
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationBar.barTintColor = UIColor.app_theme
        let textAttributes = [NSAttributedString.Key.foregroundColor:UIColor.app_title_color]
        navigationBar.titleTextAttributes = textAttributes
    }
}
