//
//  ViewController.swift
//  MVVMBaseCode
//
//  Created by sooryen on 12/06/19.
//  Copyright © 2019 sooryen. All rights reserved.
//

import UIKit
import CRRefresh

class MovieListVC: ParentVC,MovieViewModelDelegate {
    
    @IBOutlet weak var tblMovieList: UITableView!
    lazy var objMovieViewModel = MovieViewModel(self)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupData()
    }
    
    fileprivate func setupData() {
        self.title = "Movies List"
        tblMovieList.register(cellType: CellMovieList.self)
        //        tblMovieList.rowHeight = UITableView.automaticDimension
        tblMovieList.tableFooterView = UIView()
        objMovieViewModel.getMovies(inMainThread: true)
        setupPagination()
        addPullToRefreshControll()
    }
    
    fileprivate func setupPagination(){
        tblMovieList.cr.addFootRefresh {
            DispatchQueue.main.asyncAfter(deadline:.now()+0.5, execute: {
                self.objMovieViewModel.getMovies(inMainThread: false)
                /// If common end
                //                self.tblMovieList.cr.endLoadingMore()
                //                /// If no more data
                //                self.tblMovieList.cr.noticeNoMoreData()
                //                /// Reset no more data
                //                self.tblMovieList.cr.resetNoMore()
            })
        }
    }
    
    fileprivate func addPullToRefreshControll(){
        self.tblMovieList.cr.addHeadRefresh {
            DispatchQueue.main.asyncAfter(deadline:.now()+0.5, execute: {
                self.objMovieViewModel.getMovies(inMainThread: false)
            })
            
        }
    }
    
    //MARK: ViewModel Callback
    func APISuccess() {
        refreshViewData()
    }
    
    func APIFailure(message: String) {
        refreshViewData()
        tblMovieList.setEmptyMessage(message)
    }    
    //-------------
    
    fileprivate func refreshViewData() {
        tblMovieList.reloadData()
        self.tblMovieList.cr.endLoadingMore()
        self.tblMovieList.cr.endHeaderRefresh()
    }
}


//MARK: UITableViewDelegate and UITableViewDatasource
extension MovieListVC:UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return objMovieViewModel.aryMoviesList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier:"CellMovieList", for: indexPath) as! CellMovieList
        
        cell.objMovies = objMovieViewModel.aryMoviesList[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 110
    }
}
