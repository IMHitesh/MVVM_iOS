//
//  CellMovieList.swift
//  MVVMBaseCode
//
//  Created by sooryen on 13/06/19.
//  Copyright © 2019 sooryen. All rights reserved.
//

import UIKit

class CellMovieList: UITableViewCell {

    @IBOutlet weak var imgMovie: UIImageView!
    @IBOutlet weak var lblTitle: UILabel!
    
    var objMovies:MoviesList!{
        didSet {
            lblTitle.text = objMovies.title
            let strImageURL = domainImage + "w300" + String(objMovies.poster_path!)
            imgMovie.loadImageFromURL(url: strImageURL, placeholderImage:placeholderImage)
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }    
}
