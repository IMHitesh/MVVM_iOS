//
//  API.swift
//  SwiftyJson4.0
//
//  Created by Hitesh.surani on 11/10/17.
//  Copyright © 2017 Brainvire. All rights reserved.

//Alamofire Help Guide: https://github.com/Alamofire/Alamofire/blob/master/Documentation/Usage.md#response-validation


import UIKit
import Alamofire


//MARK: API METHOD NAME
struct APIConstant {
    static let parseErrorDomain = "ParseError"
    static let parseErrorMessage = "Unable to parse data"
    static let parseErrorCode = Int(UInt8.max)
    static let platform = "Iphone"
    static let content_type = "Content-Type"
    static let Authorization = "Authorization"
    static let content_value = "application/x-www-form-urlencoded"
    static let content_value_Json = "application/json"
}


struct APIName {
    static let MoviesList = "movie/popular?api_key=b42de0d7051793f886f6c0569505a420"
}


class API: NSObject {
    
    static let sharedInstance = API()
    
    private override init() {
        SMNetworkManager.shared.startNetworkReachabilityObserver()
    }
    //MARK:Multi Part Api calling
    func multipartRequestWithModalClass<T:Decodable>(modelClass:T.Type?,apiName:String, fileName:String,keyName:String,imgView:UIImageView,requestType:HTTPMethod, paramValues: Dictionary<String, Any>?, headersValues:Dictionary<String, String>?, SuccessBlock:@escaping (T) -> Void, FailureBlock:@escaping (Error)-> Void) {
        
        
        if !(SMNetworkManager.shared.isReachable!) {
            
            let view = Bundle.loadView(fromNib:"HSNetworkAlert", withType:HSNetworkAlert.self)
            view.handler = alertHandler({(index) in
                
                if (SMNetworkManager.shared.isReachable!){
                    view.removeFromSuperview()
                    self.showLoader()
                    self.multipartRequestWithModalClass(modelClass: modelClass, apiName: apiName, fileName: fileName, keyName: keyName, imgView: imgView, requestType: requestType, paramValues: paramValues, headersValues: headersValues, SuccessBlock: SuccessBlock, FailureBlock: FailureBlock)
                    self.hideLoader()
                }else{
                    
                    let viewAnimated = view.viewWithTag(7777)
                    let animation = CABasicAnimation(keyPath: "position")
                    animation.duration = 0.07
                    animation.repeatCount = 4
                    animation.autoreverses = true
                    animation.fromValue = NSValue(cgPoint: CGPoint(x: (viewAnimated?.center.x)! - 10, y: (viewAnimated?.center.y)!))
                    animation.toValue = NSValue(cgPoint: CGPoint(x: (viewAnimated?.center.x)! + 10, y: (viewAnimated?.center.y)!))
                    viewAnimated?.layer.add(animation, forKey: "position")
                }
            })
            
            if let viewToAdd = UIApplication.topViewController()?.view.viewWithTag(5022){
                view.frame = viewToAdd.bounds
                viewToAdd.addSubview(view)
            }
            self.hideLoader()
            
            return
        }
        
        let image = imgView.image
        let imgData = image!.jpegData(compressionQuality: 0.5)!
        
        Alamofire.upload(multipartFormData: { multipartFormData in
            multipartFormData.append(imgData, withName: keyName,fileName: fileName, mimeType: "image/\(imgData.fileExtension))")
            for (key, value) in paramValues! {
                multipartFormData.append((value as AnyObject).data(using: String.Encoding.utf8.rawValue)!, withName: key)
            }
        }, to: strBaseUrl + apiName, method: .post, headers: headersValues)
        { (result) in
            switch result {
            case .success(let upload, _, _):
                
                upload.responseJSON { response in
                    
                    if((response.error) != nil){
                        self.showToastMessage(title:(response.error?.localizedDescription)!)
                        FailureBlock(response.error!)
                    }
                    
                    guard let data = response.data else {
                        FailureBlock(self.handleParseError(Data())) //Show Custom Parsing Error
                        return
                    }
                    
                    do {
                        let objModalClass = try JSONDecoder().decode(modelClass!,from: data)
                        print(objModalClass)
                        SuccessBlock(objModalClass)
                    } catch let error { //If model class parsing fail
                        self.showToastMessage(title: "Oops!! There is some problem with request. Please try again")
                        
                        FailureBlock(error)
                        print(error)
                    }
                    
                }
                
            case .failure(let encodingError):
                FailureBlock(encodingError)
            }
        }
    }
    
    
    
    //MARK: - API calling with Model Class response
    func apiRequestWithModalClass<T:Decodable>(modelClass:T.Type?, apiName:String, requestType:HTTPMethod, paramValues: Dictionary<String, Any>?, headersValues:Dictionary<String, String>?,isInMainThread:Bool? = nil, SuccessBlock:@escaping (T) -> Void, FailureBlock:@escaping (Error)-> Void) {
        
        
        if !(SMNetworkManager.shared.isReachable!) {
            
            let view = Bundle.loadView(fromNib:"HSNetworkAlert", withType:HSNetworkAlert.self)
            view.handler = alertHandler({(index) in
                
                if (SMNetworkManager.shared.isReachable!){
                    view.removeFromSuperview()
                    self.showLoader()
                    self.apiRequestWithModalClass(modelClass: modelClass, apiName: apiName, requestType: requestType, paramValues: paramValues, headersValues: headersValues, SuccessBlock: SuccessBlock, FailureBlock: FailureBlock)
                    self.hideLoader()
                }else{
                    
                    let viewAnimated = view.viewWithTag(7777)
                    let animation = CABasicAnimation(keyPath: "position")
                    animation.duration = 0.07
                    animation.repeatCount = 4
                    animation.autoreverses = true
                    animation.fromValue = NSValue(cgPoint: CGPoint(x: (viewAnimated?.center.x)! - 10, y: (viewAnimated?.center.y)!))
                    animation.toValue = NSValue(cgPoint: CGPoint(x: (viewAnimated?.center.x)! + 10, y: (viewAnimated?.center.y)!))
                    viewAnimated?.layer.add(animation, forKey: "position")
                }
            })
            
            if let viewToAdd = UIApplication.topViewController()?.view.viewWithTag(5022){
                view.frame = viewToAdd.bounds
                viewToAdd.addSubview(view)
            }
            self.hideLoader()
            
            return
        }
        
        
        let url = strBaseUrl + apiName
        
        print("\n------------------------API URL---------------------\n",url)
        print("------------------------Request---------------------\n",paramValues?.description ?? "")
        Alamofire.request(url, method: requestType, parameters: paramValues, encoding: URLEncoding.httpBody, headers: headersValues).response { (response) in
            
            if((response.error) != nil){
//                self.showToastMessage(title:(response.error?.localizedDescription)!)
                FailureBlock(response.error!)
            }
            else{
                guard let data = response.data else {
                    FailureBlock(self.handleParseError(Data())) //Show Custom Parsing Error
                    return
                }
                
                
                do {
                    guard let jsonResult = try JSONSerialization.jsonObject(with: data, options:
                        JSONSerialization.ReadingOptions.allowFragments) as? NSDictionary else{
                            return
                    }
                    
                    print(jsonResult)
                }catch let error{print(error)
                    self.showToastMessage(title: "Oops!! There is some problem with request. Please try again")
                }
                
                
                do {
                    let objModalClass = try JSONDecoder().decode(modelClass!,from: data)
                    print(objModalClass)
                    SuccessBlock(objModalClass)
                } catch let error { //If model class parsing fail
                    print(String(describing: error))
                    self.showToastMessage(title: "Oops!! There is some problem with request. Please try again")
                    FailureBlock(error)
                    print(error)
                }
            }
        }
    }
    
    //MARK: - API calling with JSON data response
    func apiRequestWithJsonResponse(apiName:String, requestType:HTTPMethod, paramValues: Dictionary<String, Any>?, headersValues:Dictionary<String, String>?, SuccessBlock:@escaping (AnyObject) -> Void, FailureBlock:@escaping (Error)-> Void) {
        
        if !(SMNetworkManager.shared.isReachable!) {
            
            let view = Bundle.loadView(fromNib:"HSNetworkAlert", withType:HSNetworkAlert.self)
            view.handler = alertHandler({(index) in
                
                if (SMNetworkManager.shared.isReachable!){
                    view.removeFromSuperview()
                    self.showLoader()
                    self.apiRequestWithJsonResponse(apiName: apiName, requestType: requestType, paramValues: paramValues, headersValues: headersValues, SuccessBlock: SuccessBlock, FailureBlock: FailureBlock)
                    self.hideLoader()
                }else{
                    
                    let viewAnimated = view.viewWithTag(7777)
                    let animation = CABasicAnimation(keyPath: "position")
                    animation.duration = 0.07
                    animation.repeatCount = 4
                    animation.autoreverses = true
                    animation.fromValue = NSValue(cgPoint: CGPoint(x: (viewAnimated?.center.x)! - 10, y: (viewAnimated?.center.y)!))
                    animation.toValue = NSValue(cgPoint: CGPoint(x: (viewAnimated?.center.x)! + 10, y: (viewAnimated?.center.y)!))
                    viewAnimated?.layer.add(animation, forKey: "position")
                }
            })
            
            if let viewToAdd = UIApplication.topViewController()?.view.viewWithTag(5022){
                view.frame = viewToAdd.bounds
                viewToAdd.addSubview(view)
            }
            self.hideLoader()
            
            return
        }
        
        
        let url = strBaseUrl + apiName
        
        //        Alamofire.request(url, method: requestType, parameters: paramValues, encoding: URLEncoding.httpBody, headers: headersValues).validate().responseJSON { (response) in
        Alamofire.request(url, method: requestType, parameters: paramValues, encoding: URLEncoding.httpBody, headers: headersValues).responseJSON { (response) in
            
            switch response.result {
            case .success:
                //print("Validation Successful")
                SuccessBlock(response.result.value as AnyObject)
            case .failure(let error):
                print(error)
                self.showToastMessage(title:(response.error?.localizedDescription)!)
                FailureBlock(error)
            }
        }
    }
    
    //MARK: - Supporting Methods
    fileprivate func handleParseError(_ data: Data) -> Error{
        let error = NSError(domain:APIConstant.parseErrorDomain, code:APIConstant.parseErrorCode, userInfo:[ NSLocalizedDescriptionKey: APIConstant.parseErrorMessage])
        print(error.localizedDescription)
        do { //To print response if parsing fail
            let response  = try JSONSerialization.jsonObject(with: data, options: .allowFragments)
            print(response)
        }catch{}
        
        return error
    }
    
    //MARK: - Get HeaderParameter Method
    func getHeaderParameter() -> Dictionary<String, String>{
        
        let dictHeader = NSMutableDictionary()
        dictHeader.setValue(APIConstant.content_value, forKey: APIConstant.content_type)
        print("Header Param\(dictHeader)")
        return dictHeader as! Dictionary<String, String>
    }
    
    
    //HS:Custom API for exceptional case
    func callCustomAPIWithModalClass<T:Decodable>(modelClass:T.Type?, apiName:String, requestType:HTTPMethod, paramValues: Dictionary<String, Any>?, headersValues:Dictionary<String, String>?, SuccessBlock:@escaping (T) -> Void, FailureBlock:@escaping (Error)-> Void){
        
        do {
            let apiURL = "\(strBaseUrl)\(apiName)"
            let postData = try JSONSerialization.data(withJSONObject: paramValues ?? [], options: JSONSerialization.WritingOptions.prettyPrinted)
            
            var request = URLRequest(url: NSURL(string: apiURL)! as URL, cachePolicy: .useProtocolCachePolicy, timeoutInterval: 120)
            request.httpMethod = requestType.rawValue
            request.allHTTPHeaderFields = headersValues
            request.httpBody = postData as Data
            
            
            print("\nAPI Endpoint: \(apiURL)\n Request:\(String(describing: paramValues))")
            
            Alamofire.request(request).responseData(completionHandler: { (response) in
                if((response.error) != nil){
                    self.showToastMessage(title:(response.error?.localizedDescription)!)
                    FailureBlock(response.error!)
                }
                else{
                    guard let data = response.data else {
                        FailureBlock(self.handleParseError(Data())) //Show Custom Parsing Error
                        return
                    }
                    
                    
                    do {
                        guard let jsonResult = try JSONSerialization.jsonObject(with: data, options:
                            JSONSerialization.ReadingOptions.allowFragments) as? NSDictionary else{
                                return
                        }
                        
                        print(jsonResult)
                    }catch let error{print(error)
                        self.showToastMessage(title: "Oops!! There is some problem with request. Please try again")
                    }
                    
                    
                    do {
                        let objModalClass = try JSONDecoder().decode(modelClass!,from: data)
                        print(objModalClass)
                        SuccessBlock(objModalClass)
                    } catch let error { //If model class parsing fail
                        self.showToastMessage(title: "Oops!! There is some problem with request. Please try again")
                        
                        FailureBlock(error)
                        print(error)
                    }
                }
            })
        } catch let error {
            FailureBlock(error)
        }
    }
    
    func getJsonHeaderParameter() -> Dictionary<String, String>{
        let dictHeader = NSMutableDictionary()
        dictHeader.setValue(APIConstant.content_value_Json, forKey:APIConstant.content_type)
        return dictHeader as! Dictionary<String, String>
    }
    
}

extension NSObject{
    
    func showToastMessage(title:String) {
        DispatchQueue.main.async {
            if let toastView = APPLICATION.appDelegate.window?.viewWithTag(2532515){
                toastView.removeFromSuperview()
            }
            APPLICATION.appDelegate.window?.rootViewController?.view.makeToast(title, duration: 1.5, position: .bottom)
            ToastManager.shared.isTapToDismissEnabled = true
        }
    }
    
    func showToastMessage(title:String,view:UIView,position:ToastPosition) {
        DispatchQueue.main.async {
            
            if let toastView = APPLICATION.appDelegate.window?.viewWithTag(2532515){
                toastView.removeFromSuperview()
            }
            view.makeToast(title, duration: 2.5, position:position)
            ToastManager.shared.isTapToDismissEnabled = true
        }
    }
    
    func showToastMessage(title:String,view:UIView,position:ToastPosition,duration:TimeInterval) {
        DispatchQueue.main.async {
            
            if let toastView = APPLICATION.appDelegate.window?.viewWithTag(2532515){
                toastView.removeFromSuperview()
            }
            view.makeToast(title, duration: duration, position:position)
            ToastManager.shared.isTapToDismissEnabled = true
        }
    }
    
}

public extension Data {
    var fileExtension: String {
        var values = [UInt8](repeating:0, count:1)
        self.copyBytes(to: &values, count: 1)
        
        let ext: String
        switch (values[0]) {
        case 0xFF:
            ext = "jpg"
        case 0x89:
            ext = "png"
        case 0x47:
            ext = "gif"
        case 0x49, 0x4D :
            ext = "tiff"
        default:
            ext = "png"
        }
        return ext
    }
}

