//
//  UserDefault.swift
//  Capchur
//
//  Created by Hitesh Surani on 19/06/18.
//  Copyright © 2018 Hitesh Surani. All rights reserved.
//

import Foundation
import CoreLocation

class UserDefault: NSObject {
    static let shared:UserDefault = UserDefault()
    
    func setArrayToUserDefault(value:[String],key:String){
        let defaults = UserDefaults.standard
        defaults.set(value, forKey: key)
        defaults.synchronize()
    }
    
    func getArrayFromUserDefault(key:String) -> [String] {
        return UserDefaults.standard.stringArray(forKey: key) ?? [String]()
    }
    
    func setUserDefault(value:AnyObject,key:String){
        UserDefaults.standard.setValue(value, forKey: key)
    }
    
    func getUserDefault(key:String) -> AnyObject {
        return UserDefaults.standard.object(forKey: key) as AnyObject
    }
    
    func setStringValue(value:String,key:String){
        UserDefaults.standard.set(value, forKey:key)
    }
    
    func getStringValue(key:String) -> String {
        return UserDefaults.standard.string(forKey: key) ?? ""
    }
    
    func setIntValue(value:Int,key:String){
        UserDefaults.standard.set(value, forKey:key)
    }
    
    func getIntValue(key:String) -> Int {
        return UserDefaults.standard.integer(forKey: key)
    }
        
    func setBoolValue(value:Bool,key:String){
        UserDefaults.standard.set(value, forKey:key)
    }
    
    func getBoolValue(key:String) -> Bool {
        return UserDefaults.standard.bool(forKey: key)
    }
    
    func removeAllValueFromUserDefault(){
        let domain = Bundle.main.bundleIdentifier!
        UserDefaults.standard.removePersistentDomain(forName: domain)
        UserDefaults.standard.synchronize()
        print(Array(UserDefaults.standard.dictionaryRepresentation().keys).count)
    }
}

public extension UserDefaults {
    
    public func set<T: Codable>(object: T, forKey: String) throws {
        let jsonData = try JSONEncoder().encode(object)
        set(jsonData, forKey: forKey)
    }
    
    public func get<T: Codable>(objectType: T.Type, forKey: String) throws -> T? {
        
        guard let result = value(forKey: forKey) as? Data else {
            return nil
        }
        
        return try JSONDecoder().decode(objectType, from: result)
    }
}



