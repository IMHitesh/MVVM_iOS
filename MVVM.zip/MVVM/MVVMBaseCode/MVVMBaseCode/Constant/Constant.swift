//
//  Constant.swift
//  MVVMBaseCode
//
//  Created by sooryen on 12/06/19.
//  Copyright © 2019 sooryen. All rights reserved.
//
import UIKit

let Cons_App_Name = "MVVMBaseCode"
let placeholderImage = UIImage(named: "placeholder")!

let Cons_YES = "YES"
let Cons_NO = "NO"
let Cons_Done = "Done"
let Cons_Cancel = "Cancel"
let Cons_Camera_Not_Available = "You don't have camera"


let Cons_Logout_msg = "Are you sure you want to logout?"
let Cons_Logout = "Logout"



struct APPLICATION {
    
    @available(iOS 9.0, *)
    static let appDelegate = UIApplication.shared.delegate as! AppDelegate
    
    static let IS_IPAD = UIDevice.current.userInterfaceIdiom == .pad
    static let IS_IPHONE = UIDevice.current.userInterfaceIdiom  == .phone
    
    static var APP_STATUS_BAR_COLOR = UIColor(red: CGFloat(27.0/255.0), green: CGFloat(32.0/255.0), blue: CGFloat(42.0/255.0), alpha: 1)
    static var APP_NAVIGATION_BAR_COLOR = UIColor(red: CGFloat(41.0/255.0), green: CGFloat(48.0/255.0), blue: CGFloat(63.0/255.0), alpha: 1)
}
