//
//  Configuration.swift
//  MVVMBaseCode
//
//  Created by sooryen on 13/06/19.
//  Copyright © 2019 sooryen. All rights reserved.
//


//MARK:- API Constant
let strBaseUrl = "https://api.themoviedb.org/3/"
let domainImage = "https://image.tmdb.org/t/p/"
//------------------------



//MARK: App theme color
extension UIColor{
    static let app_theme = UIColor(red: 51.0/255.0, green:204.0/255.0, blue:255.0/255.0, alpha: 1.0)
    
    static let app_title_color = UIColor.white

    static let app_loader_bg = UIColor(red: 0, green: 0, blue: 0, alpha: 0.8)
}
//------------------------

