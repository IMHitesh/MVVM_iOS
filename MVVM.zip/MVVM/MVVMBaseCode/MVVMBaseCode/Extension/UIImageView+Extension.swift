//
//  UIImageView+Extension.swift
//  MVVMBaseCode
//
//  Created by sooryen on 13/06/19.
//  Copyright © 2019 sooryen. All rights reserved.
//

import UIKit

extension UIImageView{
    func loadImageFromURL(url:String?,placeholderImage:UIImage){
        
        guard let strURL = url, let imageURL = URL.init(string: strURL) else {
            image = placeholderImage
            return
        }
        sd_setImage(with: imageURL, placeholderImage: placeholderImage, options: .refreshCached) { (image, error, cacheType, url) in
            self.image = image
        }
    }
}
