//
//  StoryBoard+Extension.swift
//  MVVMBaseCode
//
//  Created by sooryen on 12/06/19.
//  Copyright © 2019 sooryen. All rights reserved.
//

import UIKit
extension UIViewController {
    
    //MARK:- Prepare Storyboard instances
    var MAIN_STORYBOARD_R1 : UIStoryboard{
        return UIStoryboard.init(name:"Main", bundle: nil)
    }
    
    func MAKE_STORY_OBJ(Identifier:String) -> UIViewController {
        return MAIN_STORYBOARD_R1.instantiateViewController(withIdentifier: Identifier)
    }

    
    //MARK:- Prepare XIB class
    func MAKE_CLASS_OBJ(Class:AnyClass) -> UIViewController {
        return UINib(nibName: NSStringFromClass(Class), bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! UIViewController
    }
    
    
    //MARK:- Push Storyboard class
    func PUSH_STORY(Identifier:String){
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
        self.navigationController?.pushViewController(MAKE_STORY_OBJ(Identifier: Identifier), animated: true)
    }

    //MARK:- Push created class object
    func PUSH_STORY_OBJ(obj:UIViewController){
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
        self.navigationController?.pushViewController(obj, animated: true)
    }
    
    //MARK:- Perform Segue
    func PERFORM_SEGUE(Identifier:String){
        self.performSegue(withIdentifier: Identifier, sender: nil)
    }
    
    //MARK:- POP class object
    func POP_VC(){
        removeToastView()
        
        self.navigationController?.popViewController(animated: true)
    }
    
    func POP_TO_VC<T:UIViewController>(controllerClass:T.Type?) -> Bool {
        for vc in (self.navigationController?.viewControllers) ?? []{
            if vc.isKind(of:controllerClass!) {
                self.navigationController?.popToViewController(vc, animated: true)
                
                removeToastView()
                return true
            }
        }
        return false
    }
    
    
    
    func POP_TO_ROOT() {
        removeToastView()
        self.navigationController?.popToRootViewController(animated: true)
    }
    
    fileprivate func removeToastView() {
        if let toastView = APPLICATION.appDelegate.window?.viewWithTag(2532515){
            toastView.removeFromSuperview()
        }
    }
}
